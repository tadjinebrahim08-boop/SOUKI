# سوقي بوكس: خطوات البناء

```
flutter create --org com.tajine.soukibox --project-name soukibox .
# انسخ مجلد lib و pubspec.yaml فوق الموجودين
flutter pub get
flutter build apk --release
```

## إعدادات أندرويد
1. `android/app/build.gradle`: ضع `minSdkVersion 23` (أو `minSdk = 23`).
2. `AndroidManifest.xml`: أضف قبل `<application>`:
   `<uses-permission android:name="android.permission.USE_BIOMETRIC"/>` و `<uses-permission android:name="android.permission.CAMERA"/>`
   وفي وسم `<application>` أضف: `android:allowBackup="false"`
3. `MainActivity.kt` (حماية الشاشة + البصمة):
```kotlin
import android.os.Bundle
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity
class MainActivity : FlutterFragmentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
  }
}
```
4. خط Cairo (اختياري): أضف ملفاته في assets وسجله في pubspec.

## ملف APK بدون جهاز كمبيوتر (GitHub Actions)
1. أنشئ مستودعاً خاصاً (Private) في GitHub وارفع محتوى هذا المجلد كما هو (بما فيه .github و tools).
2. تبويب Actions ثم Build APK ثم Run workflow.
3. بعد دقائق، حمّل soukibox-apk من أسفل صفحة التشغيل. هذا هو ملف APK.
(السكريبت tools/setup_android.sh يطبق إعدادات أندرويد تلقائياً.)

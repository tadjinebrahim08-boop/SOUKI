set -e
mkdir -p /tmp/keep && cp -r lib pubspec.yaml assets /tmp/keep/ 2>/dev/null || cp -r lib pubspec.yaml /tmp/keep/
flutter create --org com.tajine.soukibox --project-name soukibox .
rm -rf lib test && cp -r /tmp/keep/lib lib && cp /tmp/keep/pubspec.yaml pubspec.yaml
# Restore assets if present
if [ -d /tmp/keep/assets ]; then
  rm -rf assets
  cp -r /tmp/keep/assets assets
fi
G=$(ls android/app/build.gradle* | head -1)
sed -i -E 's/minSdk(Version)?( =)? *flutter\.minSdkVersion/minSdk = 23/' "$G"
M=android/app/src/main/AndroidManifest.xml
# Add permissions and camera feature before <application>
sed -i '0,/<application/s#<application#<uses-permission android:name="android.permission.USE_BIOMETRIC"/>\n    <uses-permission android:name="android.permission.CAMERA"/>\n    <uses-feature android:name="android.hardware.camera" android:required="false"/>\n    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false"/>\n    <application android:allowBackup="false"#' "$M"
K=$(find android/app/src/main -name 'MainActivity.kt')
P=$(grep -m1 '^package' "$K")
cat > "$K" <<KT
$P

import android.os.Bundle
import android.view.WindowManager
import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity : FlutterFragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
    }
}
KT

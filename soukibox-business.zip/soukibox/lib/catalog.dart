import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'app_state.dart';
import 'business.dart';
import 'db.dart';
import 'l10n.dart';

class CatalogItem {
  final String name;
  final String nameFr;
  final String category;
  final double price;
  final double cost;
  final String unit;
  final double minQty;
  final String biz;

  CatalogItem({
    required this.name,
    required this.nameFr,
    required this.category,
    required this.price,
    required this.cost,
    required this.unit,
    required this.minQty,
    required this.biz,
  });

  factory CatalogItem.fromJson(Map<String, dynamic> j) => CatalogItem(
        name: j['name'] as String,
        nameFr: (j['name_fr'] as String?) ?? j['name'] as String,
        category: j['category'] as String,
        price: (j['price'] as num).toDouble(),
        cost: (j['cost'] as num).toDouble(),
        unit: (j['unit'] as String?) ?? '',
        minQty: (j['min_qty'] as num?)?.toDouble() ?? 5,
        biz: (j['biz'] as String?) ?? 'super',
      );
}

IconData catIcon(String cat) {
  switch (cat) {
    case 'أساسيات':
      return Icons.kitchen_rounded;
    case 'زيوت':
      return Icons.water_drop_rounded;
    case 'ألبان وبيض':
      return Icons.egg_rounded;
    case 'مشروبات':
      return Icons.local_drink_rounded;
    case 'تنظيف':
      return Icons.cleaning_services_rounded;
    case 'عناية شخصية':
      return Icons.spa_rounded;
    case 'خضر وفواكه':
      return Icons.eco_rounded;
    case 'لحوم':
      return Icons.set_meal_rounded;
    case 'معلبات وحلويات':
      return Icons.cookie_rounded;
    case 'مخبوزات':
      return Icons.bakery_dining_rounded;
    default:
      return Icons.inventory_2_rounded;
  }
}

Color catColor(String cat) {
  switch (cat) {
    case 'أساسيات':
      return Colors.brown;
    case 'زيوت':
      return Colors.amber.shade800;
    case 'ألبان وبيض':
      return Colors.blueGrey;
    case 'مشروبات':
      return Colors.lightBlue;
    case 'تنظيف':
      return Colors.cyan;
    case 'عناية شخصية':
      return Colors.pink;
    case 'خضر وفواكه':
      return Colors.green;
    case 'لحوم':
      return Colors.red.shade700;
    case 'معلبات وحلويات':
      return Colors.deepOrange;
    case 'مخبوزات':
      return Colors.orange;
    default:
      return Colors.teal;
  }
}

class CatalogScreen extends StatefulWidget {
  const CatalogScreen({super.key});
  @override
  State<CatalogScreen> createState() => _CatalogState();
}

class _CatalogState extends State<CatalogScreen> {
  List<CatalogItem> all = [];
  List<CatalogItem> filtered = [];
  String q = '';
  String? cat;
  final selected = <CatalogItem>{};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final raw = await rootBundle.loadString('assets/catalog.json');
    final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
    final loaded = list.map(CatalogItem.fromJson).toList();
    final id = AppState.I.biz.id;
    if (AppState.I.biz == BizType.general) {
      all = loaded;
    } else {
      all = loaded.where((e) => e.biz == id).toList();
      // fallback: if empty use super
      if (all.isEmpty) all = loaded.where((e) => e.biz == 'super').toList();
    }
    _apply();
  }

  void _apply() {
    setState(() {
      filtered = all.where((p) {
        final matchQ = q.isEmpty ||
            p.name.contains(q) ||
            p.nameFr.toLowerCase().contains(q.toLowerCase());
        final matchC = cat == null || p.category == cat;
        return matchQ && matchC;
      }).toList();
    });
  }

  Future<void> _importSelected() async {
    if (selected.isEmpty) return;
    var n = 0;
    for (final p in selected) {
      try {
        await Db.saveProduct({
          'name': p.name,
          'barcode': null,
          'price': p.price,
          'cost': p.cost,
          'qty': 0,
          'min_qty': p.minQty,
        });
        n++;
      } catch (_) {}
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${L.get('save')}: $n')),
      );
      Navigator.pop(context, true);
    }
  }

  Future<void> _addOne(CatalogItem p) async {
    final priceC = TextEditingController(text: p.price.toStringAsFixed(0));
    final costC = TextEditingController(text: p.cost.toStringAsFixed(0));
    final qtyC = TextEditingController(text: '0');
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(p.name),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('${p.category} • ${p.unit}', style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 12),
          TextField(
            controller: priceC,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: '${L.get('price')} (${L.get('currency')})'),
          ),
          TextField(
            controller: costC,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: L.get('cost')),
          ),
          TextField(
            controller: qtyC,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: L.get('qty')),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(L.get('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(L.get('add'))),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Db.saveProduct({
        'name': p.name,
        'barcode': null,
        'price': double.tryParse(priceC.text) ?? p.price,
        'cost': double.tryParse(costC.text) ?? p.cost,
        'qty': double.tryParse(qtyC.text) ?? 0,
        'min_qty': p.minQty,
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(L.get('save'))));
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(L.get('barcode_exists'))));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final cats = all.map((e) => e.category).toSet().toList()..sort();
    return Scaffold(
      appBar: AppBar(
        title: Text('${L.get('stock')} • 300'),
        actions: [
          if (selected.isNotEmpty)
            TextButton(
              onPressed: _importSelected,
              child: Text('${L.get('add')} (${selected.length})'),
            ),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: TextField(
            decoration: InputDecoration(
              hintText: L.get('search_product'),
              prefixIcon: const Icon(Icons.search),
              border: const OutlineInputBorder(),
              isDense: true,
            ),
            onChanged: (v) {
              q = v.trim();
              _apply();
            },
          ),
        ),
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: FilterChip(
                  label: const Text('الكل'),
                  selected: cat == null,
                  onSelected: (_) {
                    cat = null;
                    _apply();
                  },
                ),
              ),
              for (final c in cats)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: FilterChip(
                    avatar: Icon(catIcon(c), size: 16, color: catColor(c)),
                    label: Text(c),
                    selected: cat == c,
                    onSelected: (_) {
                      cat = c;
                      _apply();
                    },
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: filtered.isEmpty
              ? Center(child: Text(L.get('no_products')))
              : ListView.builder(
                  itemCount: filtered.length,
                  itemBuilder: (_, i) {
                    final p = filtered[i];
                    final sel = selected.contains(p);
                    final col = catColor(p.category);
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: col.withValues(alpha: 0.15),
                          child: Icon(catIcon(p.category), color: col, size: 22),
                        ),
                        title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                        subtitle: Text('${p.category} • ${L.get('price')}: ${L.money(p.price)}'),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                            icon: const Icon(Icons.add_circle_outline),
                            onPressed: () => _addOne(p),
                          ),
                          Checkbox(
                            value: sel,
                            onChanged: (v) {
                              setState(() {
                                if (v == true) {
                                  selected.add(p);
                                } else {
                                  selected.remove(p);
                                }
                              });
                            },
                          ),
                        ]),
                        onTap: () => _addOne(p),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

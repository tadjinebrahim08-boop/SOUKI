import 'package:flutter/material.dart';
import 'db.dart';
import 'l10n.dart';
import 'pos.dart';
import 'catalog.dart';

class StockScreen extends StatefulWidget {
  const StockScreen({super.key});
  @override
  State<StockScreen> createState() => _StockState();
}

class _StockState extends State<StockScreen> {
  List<DbRow> items = [];
  String q = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load([String s = '']) async {
    final r = await Db.products(s);
    if (mounted) setState(() { items = r; q = s; });
  }

  Future<void> _edit([DbRow? p]) async {
    final labels = {
      'name': L.get('name'),
      'barcode': L.get('barcode'),
      'price': L.get('price'),
      'cost': L.get('cost'),
      'qty': L.get('qty'),
      'min_qty': L.get('min_qty'),
    };
    final f = {for (final k in labels.keys) k: TextEditingController(text: p?[k]?.toString() ?? '')};
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(p == null ? L.get('new_product') : L.get('edit_product')),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final e in f.entries)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: TextField(
                  controller: e.value,
                  keyboardType: e.key == 'name' || e.key == 'barcode'
                      ? TextInputType.text
                      : TextInputType.number,
                  decoration: InputDecoration(
                    labelText: labels[e.key],
                    suffixIcon: e.key == 'barcode'
                        ? IconButton(
                            icon: const Icon(Icons.qr_code_scanner),
                            onPressed: () async {
                              final c = await scanCode(context);
                              if (c != null) e.value.text = c;
                            },
                          )
                        : null,
                  ),
                ),
              ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(L.get('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(L.get('save'))),
        ],
      ),
    );
    if (ok != true || f['name']!.text.trim().isEmpty) return;
    num n(String k) => num.tryParse(f[k]!.text) ?? 0;
    final bc = f['barcode']!.text.trim();
    try {
      await Db.saveProduct({
        'id': p?['id'],
        'name': f['name']!.text.trim(),
        'barcode': bc.isEmpty ? null : bc,
        'price': n('price'),
        'cost': n('cost'),
        'qty': n('qty'),
        'min_qty': n('min_qty'),
      });
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(L.get('barcode_exists'))));
      }
    }
    _load(q);
  }

  Future<void> _delete(DbRow p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(L.get('delete_confirm')),
        content: Text('${p['name']}'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(L.get('no'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(L.get('yes'))),
        ],
      ),
    );
    if (ok == true) {
      await Db.deleteProduct(p['id'] as int);
      _load(q);
    }
  }

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.extended(
            heroTag: 'cat',
            onPressed: () async {
              final ok = await Navigator.push(c, MaterialPageRoute(builder: (_) => const CatalogScreen()));
              if (ok == true) _load(q);
            },
            icon: const Icon(Icons.menu_book_rounded),
            label: const Text('كتالوج'),
          ),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            heroTag: 'add',
            onPressed: () => _edit(),
            icon: const Icon(Icons.add),
            label: Text(L.get('add')),
          ),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: TextField(
            onChanged: _load,
            decoration: InputDecoration(
              hintText: L.get('search_product'),
              prefixIcon: const Icon(Icons.search),
              border: const OutlineInputBorder(),
            ),
          ),
        ),
        Expanded(
          child: items.isEmpty
              ? Center(child: Text(L.get('no_products')))
              : ListView.builder(
                  itemCount: items.length,
                  itemBuilder: (_, i) {
                    final p = items[i];
                    final low = (p['qty'] as num) <= (p['min_qty'] as num);
                    return Card(
                      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: low
                              ? Colors.red.withValues(alpha: 0.15)
                              : Theme.of(c).colorScheme.primaryContainer,
                          child: Icon(
                            Icons.inventory_2_rounded,
                            color: low ? Colors.red : Theme.of(c).colorScheme.primary,
                          ),
                        ),
                        title: Text('${p['name']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                        subtitle: Text(
                            '${L.money(p['price'] as num)}  •  ${L.get('stock_qty')}: ${p['qty']}'),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          if (low) const Icon(Icons.warning_amber_rounded, color: Colors.red, size: 20),
                          PopupMenuButton<String>(
                            onSelected: (v) {
                              if (v == 'edit') _edit(p);
                              if (v == 'del') _delete(p);
                            },
                            itemBuilder: (_) => [
                              PopupMenuItem(value: 'edit', child: Text(L.get('edit'))),
                              PopupMenuItem(value: 'del', child: Text(L.get('delete'))),
                            ],
                          ),
                        ]),
                        onTap: () => _edit(p),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

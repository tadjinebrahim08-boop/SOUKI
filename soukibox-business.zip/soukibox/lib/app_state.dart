import 'package:flutter/material.dart';
import 'business.dart';
import 'db.dart';
import 'l10n.dart';

class AppState extends ChangeNotifier {
  static final AppState I = AppState._();
  AppState._();

  ThemeMode themeMode = ThemeMode.system;
  Color seed = const Color(0xFF1B8A5A);
  BizType biz = BizType.superMarket;

  static const colors = [
    Color(0xFF1B8A5A),
    Color(0xFF2563EB),
    Color(0xFF7C3AED),
    Color(0xFFDC2626),
    Color(0xFFEA580C),
    Color(0xFF0891B2),
    Color(0xFF4F46E5),
    Color(0xFFDB2777),
  ];

  Future<void> load() async {
    final l = await Db.get('lang');
    if (l == 'fr') {
      L.lang = AppLang.fr;
    } else if (l == 'en') {
      L.lang = AppLang.en;
    } else {
      L.lang = AppLang.ar;
    }

    final t = await Db.get('theme');
    if (t == 'light') {
      themeMode = ThemeMode.light;
    } else if (t == 'dark') {
      themeMode = ThemeMode.dark;
    } else {
      themeMode = ThemeMode.system;
    }

    final c = await Db.get('seed');
    if (c != null) {
      final v = int.tryParse(c);
      if (v != null) seed = Color(v);
    }

    biz = BizTypeX.fromId(await Db.get('biz'));
    if (await Db.get('seed') == null) seed = biz.color;

    notifyListeners();
  }

  Future<void> setLang(AppLang l) async {
    L.lang = l;
    await Db.set('lang', l.name);
    notifyListeners();
  }

  Future<void> setTheme(ThemeMode m) async {
    themeMode = m;
    await Db.set(
        'theme',
        m == ThemeMode.light
            ? 'light'
            : m == ThemeMode.dark
                ? 'dark'
                : 'system');
    notifyListeners();
  }

  Future<void> setSeed(Color c) async {
    seed = c;
    await Db.set('seed', c.value.toString());
    notifyListeners();
  }

  Future<void> setBiz(BizType b) async {
    biz = b;
    await Db.set('biz', b.id);
    seed = b.color;
    await Db.set('seed', b.color.value.toString());
    notifyListeners();
  }

  ThemeData theme(Brightness b) => ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: b),
        cardTheme: CardThemeData(
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        appBarTheme: const AppBarTheme(centerTitle: true, elevation: 0),
        floatingActionButtonTheme: FloatingActionButtonThemeData(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          filled: true,
        ),
      );
}

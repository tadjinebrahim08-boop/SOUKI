import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'db.dart';
import 'l10n.dart';
import 'pos.dart';

Future<List<String>?> ask(BuildContext c, String title, List<String> labels, [Set<int> nums = const {}]) async {
  final cs = [for (final _ in labels) TextEditingController()];
  final ok = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        for (var i = 0; i < labels.length; i++)
          TextField(
            controller: cs[i],
            keyboardType: nums.contains(i) ? TextInputType.number : TextInputType.text,
            decoration: InputDecoration(labelText: labels[i]),
          ),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(L.get('cancel'))),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(L.get('confirm'))),
      ],
    ),
  );
  return ok == true ? cs.map((e) => e.text.trim()).toList() : null;
}

class PartiesScreen extends StatefulWidget {
  final String kind;
  const PartiesScreen(this.kind, {super.key});
  @override
  State<PartiesScreen> createState() => _PartiesState();
}

class _PartiesState extends State<PartiesScreen> {
  List<DbRow> items = [];
  bool get cust => widget.kind == 'c';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await Db.parties(widget.kind);
    if (mounted) setState(() => items = r);
  }

  Future<void> _add() async {
    final v = await ask(context, cust ? L.get('new_customer') : L.get('new_supplier'), [L.get('name'), L.get('phone')], {1});
    if (v == null || v[0].isEmpty) return;
    await Db.addParty(widget.kind, v[0], v[1]);
    _load();
  }

  Future<void> _edit(DbRow p) async {
    final nameC = TextEditingController(text: '${p['name'] ?? ''}');
    final phoneC = TextEditingController(text: '${p['phone'] ?? ''}');
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(L.get('edit')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: nameC, decoration: InputDecoration(labelText: L.get('name'))),
          TextField(controller: phoneC, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: L.get('phone'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(L.get('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(L.get('save'))),
        ],
      ),
    );
    if (ok != true || nameC.text.trim().isEmpty) return;
    await Db.updateParty(p['id'] as int, nameC.text.trim(), phoneC.text.trim());
    _load();
  }

  Future<void> _delete(DbRow p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(L.get('delete_confirm')),
        content: Text('${p['name']}'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(L.get('no'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(L.get('yes'))),
        ],
      ),
    );
    if (ok == true) {
      await Db.deleteParty(p['id'] as int);
      _load();
    }
  }

  void _copyPhone(String? phone) {
    if (phone == null || phone.isEmpty) return;
    Clipboard.setData(ClipboardData(text: phone));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${L.get('phone')}: $phone')));
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text(cust ? L.get('customers') : L.get('suppliers'))),
        floatingActionButton: FloatingActionButton(onPressed: _add, child: const Icon(Icons.person_add_alt)),
        body: items.isEmpty
            ? Center(child: Text(L.get('no_one')))
            : ListView(children: [
                for (final p in items)
                  Card(
                    margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    child: ListTile(
                      leading: CircleAvatar(
                        child: Text('${p['name']}'.isNotEmpty ? '${p['name']}'.substring(0, 1) : '?'),
                      ),
                      title: Text('${p['name']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text('${p['phone'] ?? ''}'),
                      trailing: Text(
                        L.money(p['bal'] as num),
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: (p['bal'] as num) > 0 ? Colors.red : Colors.green,
                        ),
                      ),
                      onTap: () async {
                        await Navigator.push(c, MaterialPageRoute(builder: (_) => PartyPage(p, cust)));
                        _load();
                      },
                      onLongPress: () => showModalBottomSheet(
                        context: c,
                        builder: (_) => SafeArea(
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            ListTile(
                              leading: const Icon(Icons.phone),
                              title: Text(L.get('call')),
                              onTap: () {
                                Navigator.pop(c);
                                _copyPhone(p['phone'] as String?);
                              },
                            ),
                            ListTile(
                              leading: const Icon(Icons.edit),
                              title: Text(L.get('edit')),
                              onTap: () {
                                Navigator.pop(c);
                                _edit(p);
                              },
                            ),
                            ListTile(
                              leading: const Icon(Icons.delete, color: Colors.red),
                              title: Text(L.get('delete')),
                              onTap: () {
                                Navigator.pop(c);
                                _delete(p);
                              },
                            ),
                          ]),
                        ),
                      ),
                    ),
                  ),
              ]),
      );
}

class PartyPage extends StatefulWidget {
  final DbRow p;
  final bool cust;
  const PartyPage(this.p, this.cust, {super.key});
  @override
  State<PartyPage> createState() => _PartyState();
}

class _PartyState extends State<PartyPage> {
  List<DbRow> rows = [];
  double bal = 0;
  int get id => widget.p['id'] as int;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await Db.ledger(id);
    if (mounted) {
      setState(() {
        rows = r;
        bal = r.fold(0.0, (a, e) => a + (e['amount'] as num));
      });
    }
  }

  Future<void> _entry(bool pay) async {
    final v = await ask(context, pay ? L.get('record_payment') : L.get('add_debt'), [L.get('amount'), L.get('note')], {0});
    final amt = double.tryParse(v?[0] ?? '');
    if (v == null || amt == null || amt <= 0) return;
    await Db.addLedger(id, pay ? -amt : amt, v[1].isEmpty ? (pay ? L.get('record_payment') : L.get('add_debt')) : v[1]);
    _load();
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text('${widget.p['name']}')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              bal > 0
                  ? (widget.cust ? '${L.get('debt_him')}: ' : '${L.get('debt_you')}: ') + L.money(bal)
                  : L.get('no_debt'),
              style: Theme.of(c).textTheme.headlineSmall,
            ),
          ),
          Wrap(spacing: 8, children: [
            FilledButton(onPressed: () => _entry(true), child: Text(L.get('record_payment'))),
            OutlinedButton(onPressed: () => _entry(false), child: Text(L.get('add_debt'))),
            if (!widget.cust)
              OutlinedButton(
                onPressed: () async {
                  await Navigator.push(c, MaterialPageRoute(builder: (_) => PurchaseScreen(id)));
                  _load();
                },
                child: Text(L.get('purchase_invoice')),
              ),
          ]),
          const Divider(),
          Expanded(
            child: ListView(children: [
              for (final r in rows)
                ListTile(
                  dense: true,
                  title: Text('${r['note']}'),
                  subtitle: Text('${r['ts']}'.length >= 10 ? '${r['ts']}'.substring(0, 10) : '${r['ts']}'),
                  trailing: Text(L.money(r['amount'] as num),
                      style: TextStyle(color: (r['amount'] as num) > 0 ? Colors.red : Colors.green)),
                ),
            ]),
          ),
        ]),
      );
}

class PurchaseScreen extends StatefulWidget {
  final int sid;
  const PurchaseScreen(this.sid, {super.key});
  @override
  State<PurchaseScreen> createState() => _PurchaseState();
}

class _PurchaseState extends State<PurchaseScreen> {
  List<DbRow> res = [];
  final lines = <DbRow>[];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load([String s = '']) async {
    final r = await Db.products(s);
    if (mounted) setState(() => res = r);
  }

  double get total => lines.fold(0.0, (a, l) => a + (l['qty'] as double) * (l['cost'] as double));

  Future<void> _add(DbRow p) async {
    final v = await ask(context, '${p['name']}', [L.get('qty'), L.get('unit_cost')], {0, 1});
    final q = double.tryParse(v?[0] ?? '') ?? 0;
    if (v == null || q <= 0) return;
    setState(() => lines.add({'id': p['id'], 'name': p['name'], 'qty': q, 'cost': double.tryParse(v[1]) ?? 0.0}));
  }

  Future<void> _save() async {
    if (lines.isEmpty) return;
    final v = await ask(context, '${L.get('total')} ${L.money(total)}', [L.get('paid')], {0});
    if (v == null) return;
    final paid = (double.tryParse(v[0]) ?? 0).clamp(0, total).toDouble();
    await Db.purchase(widget.sid, lines, total, paid);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text(L.get('purchase_invoice'))),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              onChanged: _load,
              decoration: InputDecoration(
                hintText: L.get('search_product'),
                prefixIcon: const Icon(Icons.search),
                border: const OutlineInputBorder(),
              ),
            ),
          ),
          Expanded(
            child: ListView(children: [
              for (final p in res)
                ListTile(
                  dense: true,
                  title: Text('${p['name']}'),
                  subtitle: Text('${L.get('stock_qty')}: ${p['qty']}'),
                  onTap: () => _add(p),
                ),
            ]),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView(children: [
              for (final l in lines)
                ListTile(
                  dense: true,
                  title: Text('${l['name']}'),
                  subtitle: Text('${l['qty']} × ${L.money(l['cost'] as double)}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => setState(() => lines.remove(l)),
                  ),
                ),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(children: [
              Text(L.money(total), style: Theme.of(c).textTheme.headlineSmall),
              const Spacer(),
              FilledButton(onPressed: _save, child: Text(L.get('save'))),
            ]),
          ),
        ]),
      );
}

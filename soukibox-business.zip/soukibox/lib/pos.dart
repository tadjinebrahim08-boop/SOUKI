import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'app_state.dart';
import 'db.dart';
import 'l10n.dart';

class Line {
  final DbRow p;
  double q;
  Line(this.p, [this.q = 1]);
  double get price => (p['price'] as num).toDouble();
}

final cart = <Line>[];

// Keep da for backward compat in other files; prefer L.money
String da(num v) => L.money(v);

Future<String?> scanCode(BuildContext c) async {
  final controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.normal,
    facing: CameraFacing.back,
  );
  var done = false;

  final result = await Navigator.push<String>(
    c,
    MaterialPageRoute(
      builder: (ctx) => Scaffold(
        appBar: AppBar(title: Text(L.get('scan_barcode'))),
        body: MobileScanner(
          controller: controller,
          errorBuilder: (context, error, child) {
            final isPermission = error.errorCode == MobileScannerErrorCode.permissionDenied;
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      isPermission ? Icons.no_photography : Icons.warning_amber_rounded,
                      size: 64,
                      color: Colors.orange,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      isPermission ? L.get('camera_perm') : '${L.get('camera_fail')}\n${error.errorDetails?.message ?? error.errorCode.name}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 24),
                    FilledButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: Text(L.get('back')),
                    ),
                  ],
                ),
              ),
            );
          },
          onDetect: (cap) {
            final v = cap.barcodes.firstOrNull?.rawValue;
            if (v != null && !done) {
              done = true;
              Navigator.pop(ctx, v);
            }
          },
        ),
      ),
    ),
  );

  controller.dispose();
  return result;
}

class PosScreen extends StatefulWidget {
  const PosScreen({super.key});
  @override
  State<PosScreen> createState() => _PosState();
}

class _PosState extends State<PosScreen> {
  List<DbRow> res = [];
  final q = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load([String s = '']) async {
    final r = await Db.products(s);
    if (mounted) setState(() => res = r);
  }

  double get total => cart.fold(0.0, (a, l) => a + l.price * l.q);
  void _msg(String t) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(t)));

  void _add(DbRow p) {
    if ((p['qty'] as num) <= 0) return _msg(L.get('out_of_stock'));
    final i = cart.indexWhere((l) => l.p['id'] == p['id']);
    setState(() => i >= 0 ? cart[i].q++ : cart.add(Line(p)));
  }

  Future<void> _scan() async {
    final code = await scanCode(context);
    if (code == null) return;
    final r = await Db.products(code);
    r.isNotEmpty ? _add(r.first) : _msg(L.get('not_found'));
  }

  Future<void> _pay() async {
    if (cart.isEmpty) return;
    final c = TextEditingController(text: total.toStringAsFixed(0));
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('${L.get('total')} ${L.money(total)}'),
        content: TextField(
          controller: c,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: L.get('amount_received')),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(L.get('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(L.get('confirm'))),
        ],
      ),
    );
    if (ok != true) return;
    final paid = double.tryParse(c.text) ?? total;
    int? cid;
    if (paid < total) {
      cid = await _pickCustomer();
      if (cid == null) return;
    }
    await Db.checkout(
      cart
          .map((l) => <String, Object?>{
                'id': l.p['id'],
                'name': l.p['name'],
                'price': l.price,
                'cost': l.p['cost'],
                'qty': l.q,
              })
          .toList(),
      total,
      paid,
      cid,
    );
    final change = paid > total ? paid - total : 0.0;
    final linesCopy = List<Line>.from(cart);
    final totalCopy = total;
    final paidCopy = paid;
    cart.clear();
    await _load(q.text);
    _msg('${L.get('sale_done')}. ${L.get('change')}: ${L.money(change)}');
    if (mounted) _showReceipt(linesCopy, totalCopy, paidCopy, change);
  }

  void _showReceipt(List<Line> lines, double total, double paid, double change) {
    final shop = AppState.I; // placeholder
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(L.get('sale_done')),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(DateTime.now().toString().substring(0, 19), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
              const Divider(),
              for (final l in lines)
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('${l.p['name']} x${l.q.toStringAsFixed(0)}')),
                    Text(L.money(l.price * l.q)),
                  ],
                ),
              const Divider(),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(L.get('total'), style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(L.money(total), style: const TextStyle(fontWeight: FontWeight.bold)),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Text(L.get('paid')),
                Text(L.money(paid)),
              ]),
              if (change > 0)
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text(L.get('change')),
                  Text(L.money(change)),
                ]),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              final buf = StringBuffer();
              buf.writeln(L.get('app_name'));
              buf.writeln(DateTime.now().toString().substring(0, 19));
              buf.writeln('---');
              for (final l in lines) {
                buf.writeln('${l.p['name']} x${l.q.toStringAsFixed(0)} = ${L.money(l.price * l.q)}');
              }
              buf.writeln('---');
              buf.writeln('${L.get('total')}: ${L.money(total)}');
              buf.writeln('${L.get('paid')}: ${L.money(paid)}');
              if (change > 0) buf.writeln('${L.get('change')}: ${L.money(change)}');
              Clipboard.setData(ClipboardData(text: buf.toString()));
              Navigator.pop(ctx);
              _msg(L.lang == AppLang.fr ? 'Reçu copié' : L.lang == AppLang.en ? 'Receipt copied' : 'تم نسخ الوصل');
            },
            child: Text(L.lang == AppLang.fr ? 'Copier' : L.lang == AppLang.en ? 'Copy' : 'نسخ الوصل'),
          ),
          FilledButton(onPressed: () => Navigator.pop(ctx), child: Text(L.get('confirm'))),
        ],
      ),
    );
  }

  Future<int?> _pickCustomer() async {
    final cs = await Db.parties('c');
    if (cs.isEmpty) {
      _msg(L.get('add_customer_first'));
      return null;
    }
    if (!mounted) return null;
    return showDialog<int>(
      context: context,
      builder: (_) => SimpleDialog(
        title: Text(L.get('credit_on')),
        children: [
          for (final p in cs)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(context, p['id'] as int),
              child: Text('${p['name']}'),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext c) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: TextField(
            controller: q,
            onChanged: _load,
            decoration: InputDecoration(
              hintText: L.get('search_product'),
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(icon: const Icon(Icons.qr_code_scanner), onPressed: _scan),
              border: const OutlineInputBorder(),
            ),
          ),
        ),
        Expanded(
          flex: 2,
          child: ListView(children: [
            for (final p in res)
              ListTile(
                dense: true,
                title: Text('${p['name']}'),
                subtitle: Text('${L.get('stock_qty')}: ${p['qty']}'),
                trailing: Text(L.money(p['price'] as num)),
                onTap: () => _add(p),
              ),
          ]),
        ),
        const Divider(height: 1),
        Expanded(
          flex: 2,
          child: ListView(children: [
            for (final l in cart)
              ListTile(
                dense: true,
                title: Text('${l.p['name']}'),
                subtitle: Text(L.money(l.price * l.q)),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline),
                    onPressed: () => setState(() => l.q > 1 ? l.q-- : cart.remove(l)),
                  ),
                  Text('${l.q.toStringAsFixed(0)}'),
                  IconButton(
                    icon: const Icon(Icons.add_circle_outline),
                    onPressed: () => setState(() => l.q++),
                  ),
                ]),
              ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Text(L.money(total), style: Theme.of(c).textTheme.headlineSmall),
            const Spacer(),
            FilledButton.icon(
              onPressed: _pay,
              icon: const Icon(Icons.payments_outlined),
              label: Text(L.get('pay')),
            ),
          ]),
        ),
      ]);
}

import 'package:flutter/material.dart';

enum AppLang { ar, fr, en }

class L {
  static AppLang lang = AppLang.ar;

  static TextDirection get dir => lang == AppLang.ar ? TextDirection.rtl : TextDirection.ltr;
  static bool get isRtl => lang == AppLang.ar;

  static String get(String key) {
    final m = _t[key];
    if (m == null) return key;
    return m[lang] ?? m[AppLang.ar] ?? key;
  }

  static String n(num v, {int d = 0}) {
    final s = v.toStringAsFixed(d);
    if (lang == AppLang.ar) {
      // Arabic-Indic digits optional; keep Western for POS clarity, add thousand sep
      return s.replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ' ');
    }
    if (lang == AppLang.fr) {
      return s.replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ' ').replaceAll('.', ',');
    }
    return s.replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  }

  static String money(num v) => '${n(v, d: 0)} ${get('currency')}';

  static const _t = <String, Map<AppLang, String>>{
    'app_name': {AppLang.ar: 'سوقي بوكس', AppLang.fr: 'Souki Box', AppLang.en: 'Souki Box'},
    'tagline': {AppLang.ar: 'تجارتك محسوبة.. وأسرارك محفوظة', AppLang.fr: 'Votre commerce calculé.. vos secrets protégés', AppLang.en: 'Your business counted.. your secrets safe'},
    'sell': {AppLang.ar: 'بيع', AppLang.fr: 'Vente', AppLang.en: 'Sell'},
    'stock': {AppLang.ar: 'مخزون', AppLang.fr: 'Stock', AppLang.en: 'Stock'},
    'more': {AppLang.ar: 'المزيد', AppLang.fr: 'Plus', AppLang.en: 'More'},
    'settings': {AppLang.ar: 'الإعدادات', AppLang.fr: 'Paramètres', AppLang.en: 'Settings'},
    'customers': {AppLang.ar: 'الزبائن والكريدي', AppLang.fr: 'Clients & crédit', AppLang.en: 'Customers & credit'},
    'suppliers': {AppLang.ar: 'الموردون والمشتريات', AppLang.fr: 'Fournisseurs', AppLang.en: 'Suppliers'},
    'reports': {AppLang.ar: 'التقارير', AppLang.fr: 'Rapports', AppLang.en: 'Reports'},
    'expenses': {AppLang.ar: 'المصاريف', AppLang.fr: 'Dépenses', AppLang.en: 'Expenses'},
    'language': {AppLang.ar: 'اللغة', AppLang.fr: 'Langue', AppLang.en: 'Language'},
    'theme': {AppLang.ar: 'المظهر', AppLang.fr: 'Thème', AppLang.en: 'Theme'},
    'theme_light': {AppLang.ar: 'فاتح', AppLang.fr: 'Clair', AppLang.en: 'Light'},
    'theme_dark': {AppLang.ar: 'داكن', AppLang.fr: 'Sombre', AppLang.en: 'Dark'},
    'theme_system': {AppLang.ar: 'حسب النظام', AppLang.fr: 'Système', AppLang.en: 'System'},
    'color': {AppLang.ar: 'اللون الرئيسي', AppLang.fr: 'Couleur principale', AppLang.en: 'Primary color'},
    'save': {AppLang.ar: 'حفظ', AppLang.fr: 'Enregistrer', AppLang.en: 'Save'},
    'cancel': {AppLang.ar: 'إلغاء', AppLang.fr: 'Annuler', AppLang.en: 'Cancel'},
    'delete': {AppLang.ar: 'حذف', AppLang.fr: 'Supprimer', AppLang.en: 'Delete'},
    'edit': {AppLang.ar: 'تعديل', AppLang.fr: 'Modifier', AppLang.en: 'Edit'},
    'add': {AppLang.ar: 'إضافة', AppLang.fr: 'Ajouter', AppLang.en: 'Add'},
    'confirm': {AppLang.ar: 'تأكيد', AppLang.fr: 'Confirmer', AppLang.en: 'Confirm'},
    'search_product': {AppLang.ar: 'ابحث عن منتج', AppLang.fr: 'Rechercher un produit', AppLang.en: 'Search product'},
    'pay': {AppLang.ar: 'دفع', AppLang.fr: 'Payer', AppLang.en: 'Pay'},
    'total': {AppLang.ar: 'المجموع', AppLang.fr: 'Total', AppLang.en: 'Total'},
    'qty': {AppLang.ar: 'الكمية', AppLang.fr: 'Quantité', AppLang.en: 'Qty'},
    'price': {AppLang.ar: 'سعر البيع', AppLang.fr: 'Prix de vente', AppLang.en: 'Sell price'},
    'cost': {AppLang.ar: 'سعر الشراء', AppLang.fr: 'Prix d\'achat', AppLang.en: 'Cost'},
    'barcode': {AppLang.ar: 'الباركود', AppLang.fr: 'Code-barres', AppLang.en: 'Barcode'},
    'name': {AppLang.ar: 'الاسم', AppLang.fr: 'Nom', AppLang.en: 'Name'},
    'phone': {AppLang.ar: 'الهاتف', AppLang.fr: 'Téléphone', AppLang.en: 'Phone'},
    'min_qty': {AppLang.ar: 'حد التنبيه', AppLang.fr: 'Seuil d\'alerte', AppLang.en: 'Min qty'},
    'new_product': {AppLang.ar: 'منتج جديد', AppLang.fr: 'Nouveau produit', AppLang.en: 'New product'},
    'edit_product': {AppLang.ar: 'تعديل المنتج', AppLang.fr: 'Modifier produit', AppLang.en: 'Edit product'},
    'no_products': {AppLang.ar: 'لا توجد منتجات، أضف أول منتج', AppLang.fr: 'Aucun produit', AppLang.en: 'No products yet'},
    'out_of_stock': {AppLang.ar: 'السلعة منتهية من المخزون', AppLang.fr: 'Rupture de stock', AppLang.en: 'Out of stock'},
    'not_found': {AppLang.ar: 'المنتج غير موجود', AppLang.fr: 'Produit introuvable', AppLang.en: 'Product not found'},
    'barcode_exists': {AppLang.ar: 'هذا الباركود موجود من قبل', AppLang.fr: 'Code-barres déjà utilisé', AppLang.en: 'Barcode already exists'},
    'scan_barcode': {AppLang.ar: 'امسح الباركود', AppLang.fr: 'Scanner le code', AppLang.en: 'Scan barcode'},
    'amount_received': {AppLang.ar: 'المبلغ المقبوض', AppLang.fr: 'Montant reçu', AppLang.en: 'Amount received'},
    'change': {AppLang.ar: 'الباقي', AppLang.fr: 'Monnaie', AppLang.en: 'Change'},
    'sale_done': {AppLang.ar: 'تم البيع', AppLang.fr: 'Vente enregistrée', AppLang.en: 'Sale completed'},
    'credit_on': {AppLang.ar: 'الدين على من؟', AppLang.fr: 'Crédit pour qui ?', AppLang.en: 'Credit for whom?'},
    'add_customer_first': {AppLang.ar: 'أضف زبوناً أولاً من: المزيد > الزبائن', AppLang.fr: 'Ajoutez un client d\'abord', AppLang.en: 'Add a customer first'},
    'new_customer': {AppLang.ar: 'زبون جديد', AppLang.fr: 'Nouveau client', AppLang.en: 'New customer'},
    'new_supplier': {AppLang.ar: 'مورد جديد', AppLang.fr: 'Nouveau fournisseur', AppLang.en: 'New supplier'},
    'no_one': {AppLang.ar: 'لا يوجد أحد بعد', AppLang.fr: 'Aucun contact', AppLang.en: 'No one yet'},
    'debt_him': {AppLang.ar: 'الدين عليه', AppLang.fr: 'Il doit', AppLang.en: 'He owes'},
    'debt_you': {AppLang.ar: 'الدين عليك', AppLang.fr: 'Vous devez', AppLang.en: 'You owe'},
    'no_debt': {AppLang.ar: 'لا يوجد دين', AppLang.fr: 'Aucune dette', AppLang.en: 'No debt'},
    'record_payment': {AppLang.ar: 'تسجيل دفعة', AppLang.fr: 'Enregistrer paiement', AppLang.en: 'Record payment'},
    'add_debt': {AppLang.ar: 'إضافة دين', AppLang.fr: 'Ajouter dette', AppLang.en: 'Add debt'},
    'purchase_invoice': {AppLang.ar: 'فاتورة شراء', AppLang.fr: 'Facture d\'achat', AppLang.en: 'Purchase invoice'},
    'amount': {AppLang.ar: 'المبلغ', AppLang.fr: 'Montant', AppLang.en: 'Amount'},
    'note': {AppLang.ar: 'ملاحظة', AppLang.fr: 'Note', AppLang.en: 'Note'},
    'currency': {AppLang.ar: 'د.ج', AppLang.fr: 'DA', AppLang.en: 'DZD'},
    'enter_pin': {AppLang.ar: 'أدخل الرمز', AppLang.fr: 'Entrez le code', AppLang.en: 'Enter PIN'},
    'forgot_pin': {AppLang.ar: 'نسيت الرمز؟', AppLang.fr: 'Code oublié ?', AppLang.en: 'Forgot PIN?'},
    'locked': {AppLang.ar: 'مقفل مؤقتاً', AppLang.fr: 'Verrouillé temporairement', AppLang.en: 'Temporarily locked'},
    'wrong_pin': {AppLang.ar: 'الرمز غير صحيح', AppLang.fr: 'Code incorrect', AppLang.en: 'Wrong PIN'},
    'delete_confirm': {AppLang.ar: 'هل تريد الحذف؟', AppLang.fr: 'Confirmer la suppression ?', AppLang.en: 'Delete permanently?'},
    'yes': {AppLang.ar: 'نعم', AppLang.fr: 'Oui', AppLang.en: 'Yes'},
    'no': {AppLang.ar: 'لا', AppLang.fr: 'Non', AppLang.en: 'No'},
    'today_sales': {AppLang.ar: 'مبيعات اليوم', AppLang.fr: 'Ventes du jour', AppLang.en: 'Today sales'},
    'today_profit': {AppLang.ar: 'ربح اليوم', AppLang.fr: 'Bénéfice du jour', AppLang.en: 'Today profit'},
    'low_stock': {AppLang.ar: 'منتجات منخفضة', AppLang.fr: 'Stock bas', AppLang.en: 'Low stock'},
    'expenses_today': {AppLang.ar: 'مصاريف اليوم', AppLang.fr: 'Dépenses du jour', AppLang.en: 'Today expenses'},
    'add_expense': {AppLang.ar: 'مصروف جديد', AppLang.fr: 'Nouvelle dépense', AppLang.en: 'New expense'},
    'category': {AppLang.ar: 'التصنيف', AppLang.fr: 'Catégorie', AppLang.en: 'Category'},
    'about': {AppLang.ar: 'حول التطبيق', AppLang.fr: 'À propos', AppLang.en: 'About'},
    'shop_info': {AppLang.ar: 'معلومات المحل', AppLang.fr: 'Infos magasin', AppLang.en: 'Shop info'},
    'security': {AppLang.ar: 'الأمان', AppLang.fr: 'Sécurité', AppLang.en: 'Security'},
    'change_pin': {AppLang.ar: 'تغيير الرمز', AppLang.fr: 'Changer le code', AppLang.en: 'Change PIN'},
    'biometric': {AppLang.ar: 'البصمة', AppLang.fr: 'Biométrie', AppLang.en: 'Biometric'},
    'arabic': {AppLang.ar: 'العربية', AppLang.fr: 'Arabe', AppLang.en: 'Arabic'},
    'french': {AppLang.ar: 'الفرنسية', AppLang.fr: 'Français', AppLang.en: 'French'},
    'english': {AppLang.ar: 'الإنجليزية', AppLang.fr: 'Anglais', AppLang.en: 'English'},
    'call': {AppLang.ar: 'اتصال', AppLang.fr: 'Appeler', AppLang.en: 'Call'},
    'stock_qty': {AppLang.ar: 'المخزون', AppLang.fr: 'Stock', AppLang.en: 'Stock'},
    'paid': {AppLang.ar: 'المدفوع', AppLang.fr: 'Payé', AppLang.en: 'Paid'},
    'unit_cost': {AppLang.ar: 'سعر الشراء للوحدة', AppLang.fr: 'Coût unitaire', AppLang.en: 'Unit cost'},
    'camera_perm': {AppLang.ar: 'يجب السماح بالوصول إلى الكاميرا من إعدادات التطبيق', AppLang.fr: 'Autorisez la caméra dans les paramètres', AppLang.en: 'Allow camera in app settings'},
    'camera_fail': {AppLang.ar: 'تعذر فتح الكاميرا', AppLang.fr: 'Impossible d\'ouvrir la caméra', AppLang.en: 'Could not open camera'},
    'back': {AppLang.ar: 'رجوع', AppLang.fr: 'Retour', AppLang.en: 'Back'},
    'welcome': {AppLang.ar: 'مرحباً بك في سوقي بوكس', AppLang.fr: 'Bienvenue sur Souki Box', AppLang.en: 'Welcome to Souki Box'},
    'start': {AppLang.ar: 'ابدأ', AppLang.fr: 'Commencer', AppLang.en: 'Start'},
    'merchant_data': {AppLang.ar: 'بيانات التاجر والمحل', AppLang.fr: 'Données du commerçant', AppLang.en: 'Merchant & shop info'},
    'merchant_name': {AppLang.ar: 'اسم التاجر *', AppLang.fr: 'Nom du commerçant *', AppLang.en: 'Merchant name *'},
    'shop_name': {AppLang.ar: 'اسم المحل *', AppLang.fr: 'Nom du magasin *', AppLang.en: 'Shop name *'},
    'wilaya': {AppLang.ar: 'الولاية', AppLang.fr: 'Wilaya', AppLang.en: 'Province'},
    'continue': {AppLang.ar: 'متابعة', AppLang.fr: 'Continuer', AppLang.en: 'Continue'},
    'create_pin': {AppLang.ar: 'أنشئ رمز PIN من 6 أرقام', AppLang.fr: 'Créez un code PIN à 6 chiffres', AppLang.en: 'Create a 6-digit PIN'},
    'confirm_pin': {AppLang.ar: 'أعد إدخال الرمز للتأكيد', AppLang.fr: 'Confirmez le code', AppLang.en: 'Confirm PIN'},
    'enable_bio': {AppLang.ar: 'تفعيل البصمة', AppLang.fr: 'Activer la biométrie', AppLang.en: 'Enable biometric'},
    'recovery_code': {AppLang.ar: 'رمز الاسترجاع', AppLang.fr: 'Code de récupération', AppLang.en: 'Recovery code'},
    'recovery_hint': {AppLang.ar: 'اكتبه في ورقة واحفظها في مكان آمن. هو الطريقة الوحيدة لتغيير الـPIN إذا نسيته. لن يظهر مرة أخرى.', AppLang.fr: 'Notez-le et conservez-le en lieu sûr. C\'est le seul moyen de réinitialiser le PIN.', AppLang.en: 'Write it down and keep it safe. It is the only way to reset your PIN.'},
    'i_saved': {AppLang.ar: 'كتبته وحفظته', AppLang.fr: 'Je l\'ai noté', AppLang.en: 'I saved it'},
    'enter': {AppLang.ar: 'دخول', AppLang.fr: 'Entrer', AppLang.en: 'Enter'},
    'required_fields': {AppLang.ar: 'اسم التاجر واسم المحل مطلوبان', AppLang.fr: 'Nom et magasin obligatoires', AppLang.en: 'Merchant and shop name required'},
    'pin_mismatch': {AppLang.ar: 'الرمزان غير متطابقين', AppLang.fr: 'Les codes ne correspondent pas', AppLang.en: 'PINs do not match'},
    'signature': {AppLang.ar: 'طاجين إبراهيم 2026', AppLang.fr: 'Tadjine Brahim 2026', AppLang.en: 'Tadjine Brahim 2026'},
  };
}

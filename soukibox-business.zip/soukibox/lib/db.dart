import 'dart:convert';
import 'dart:math';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path/path.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';

typedef DbRow = Map<String, Object?>;

class Db {
  static late Database d;

  static Future<void> init() async {
    const s = FlutterSecureStorage();
    var k = await s.read(key: 'dbkey');
    if (k == null) {
      final r = Random.secure();
      k = base64Url.encode(List.generate(32, (_) => r.nextInt(256)));
      await s.write(key: 'dbkey', value: k);
    }
    d = await openDatabase(join(await getDatabasesPath(), 'soukibox.db'),
        password: k, version: 3, onUpgrade: (db, o, n) async {
      if (o < 2) await _v2(db);
      if (o < 3) await _v3(db);
    }, onCreate: (db, v) async {
      await db.execute(
          'CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT)');
      await db.execute(
          'CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, barcode TEXT UNIQUE, price REAL NOT NULL, cost REAL DEFAULT 0, qty REAL DEFAULT 0, min_qty REAL DEFAULT 5)');
      await db.execute(
          'CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, total REAL, paid REAL, customer_id INTEGER)');
      await db.execute(
          'CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER, product_id INTEGER, name TEXT, price REAL, cost REAL, qty REAL)');
      await _v2(db);
      await _v3(db);
    });
  }

  static Future<void> _v2(Database db) async {
    try {
      await db.execute('ALTER TABLE sales ADD COLUMN customer_id INTEGER');
    } catch (_) {}
    await db.execute(
        'CREATE TABLE IF NOT EXISTS parties(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, name TEXT NOT NULL, phone TEXT)');
    await db.execute(
        'CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, party_id INTEGER, ts TEXT, amount REAL, note TEXT)');
    await db.execute(
        'CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT, party_id INTEGER, ts TEXT, total REAL, paid REAL)');
    await db.execute(
        'CREATE TABLE IF NOT EXISTS purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER, product_id INTEGER, name TEXT, cost REAL, qty REAL)');
  }

  static Future<void> _v3(Database db) async {
    await db.execute(
        'CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, amount REAL, category TEXT, note TEXT)');
  }

  static String get _now => DateTime.now().toIso8601String();

  static Future<String?> get(String k) async {
    final r = await d.query('settings', where: 'k=?', whereArgs: [k]);
    return r.isEmpty ? null : r.first['v'] as String;
  }

  static Future<void> set(String k, String v) async {
    await d.insert('settings', {'k': k, 'v': v},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  static Future<List<DbRow>> products([String q = '']) => d.query('products',
      where: q.isEmpty ? null : 'name LIKE ? OR barcode=?',
      whereArgs: q.isEmpty ? null : ['%$q%', q],
      orderBy: 'name');

  static Future<void> saveProduct(DbRow m) async {
    if (m['id'] == null) {
      m.remove('id');
      await d.insert('products', m);
    } else {
      await d.update('products', m, where: 'id=?', whereArgs: [m['id']]);
    }
  }

  static Future<void> deleteProduct(int id) async {
    await d.delete('products', where: 'id=?', whereArgs: [id]);
  }

  static Future<void> checkout(List<DbRow> lines, double total, double paid,
      [int? customerId]) =>
      d.transaction((t) async {
        final id = await t.insert('sales', {
          'ts': _now,
          'total': total,
          'paid': paid,
          'customer_id': customerId
        });
        for (final l in lines) {
          await t.insert('sale_items', {
            'sale_id': id,
            'product_id': l['id'],
            'name': l['name'],
            'price': l['price'],
            'cost': l['cost'],
            'qty': l['qty']
          });
          await t.rawUpdate(
              'UPDATE products SET qty=qty-? WHERE id=?', [l['qty'], l['id']]);
        }
        if (customerId != null && paid < total) {
          await t.insert('ledger', {
            'party_id': customerId,
            'ts': _now,
            'amount': total - paid,
            'note': 'بيع بالكريدي #$id'
          });
        }
      });

  static Future<List<DbRow>> parties(String kind) => d.rawQuery(
      'SELECT p.*, COALESCE((SELECT SUM(amount) FROM ledger WHERE party_id=p.id),0) AS bal FROM parties p WHERE kind=? ORDER BY name',
      [kind]);

  static Future<void> addParty(String kind, String name, String phone) async {
    await d.insert('parties', {'kind': kind, 'name': name, 'phone': phone});
  }

  static Future<void> updateParty(int id, String name, String phone) async {
    await d.update('parties', {'name': name, 'phone': phone},
        where: 'id=?', whereArgs: [id]);
  }

  static Future<void> deleteParty(int id) async {
    await d.delete('ledger', where: 'party_id=?', whereArgs: [id]);
    await d.delete('parties', where: 'id=?', whereArgs: [id]);
  }

  static Future<void> addLedger(int pid, double amt, String note) async {
    await d.insert(
        'ledger', {'party_id': pid, 'ts': _now, 'amount': amt, 'note': note});
  }

  static Future<List<DbRow>> ledger(int pid) =>
      d.query('ledger', where: 'party_id=?', whereArgs: [pid], orderBy: 'id DESC');

  static Future<void> purchase(
          int sid, List<DbRow> lines, double total, double paid) =>
      d.transaction((t) async {
        final id = await t.insert('purchases',
            {'party_id': sid, 'ts': _now, 'total': total, 'paid': paid});
        for (final l in lines) {
          await t.insert('purchase_items', {
            'purchase_id': id,
            'product_id': l['id'],
            'name': l['name'],
            'cost': l['cost'],
            'qty': l['qty']
          });
          await t.rawUpdate(
              'UPDATE products SET qty=qty+?, cost=? WHERE id=?',
              [l['qty'], l['cost'], l['id']]);
        }
        if (paid < total) {
          await t.insert('ledger', {
            'party_id': sid,
            'ts': _now,
            'amount': total - paid,
            'note': 'فاتورة شراء #$id'
          });
        }
      });

  static Future<void> addExpense(double amount, String category, String note) async {
    await d.insert('expenses',
        {'ts': _now, 'amount': amount, 'category': category, 'note': note});
  }

  static Future<void> deleteExpense(int id) async {
    await d.delete('expenses', where: 'id=?', whereArgs: [id]);
  }

  static Future<List<DbRow>> expenses({String? day}) async {
    if (day != null) {
      return d.query('expenses',
          where: 'ts LIKE ?', whereArgs: ['$day%'], orderBy: 'id DESC');
    }
    return d.query('expenses', orderBy: 'id DESC', limit: 100);
  }

  static Future<Map<String, double>> todayStats() async {
    final day = DateTime.now().toIso8601String().substring(0, 10);
    final sales = await d.rawQuery(
        'SELECT COALESCE(SUM(total),0) as t FROM sales WHERE ts LIKE ?',
        ['$day%']);
    final profit = await d.rawQuery(
        'SELECT COALESCE(SUM((si.price-si.cost)*si.qty),0) as pr FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.ts LIKE ?',
        ['$day%']);
    final exp = await d.rawQuery(
        'SELECT COALESCE(SUM(amount),0) as e FROM expenses WHERE ts LIKE ?',
        ['$day%']);
    final low = await d
        .rawQuery('SELECT COUNT(*) as c FROM products WHERE qty <= min_qty');
    return {
      'sales': (sales.first['t'] as num).toDouble(),
      'profit': (profit.first['pr'] as num).toDouble(),
      'expenses': (exp.first['e'] as num).toDouble(),
      'low': (low.first['c'] as num).toDouble(),
    };
  }
}

import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';
import 'db.dart';
import 'app_state.dart';
import 'main.dart';
import 'l10n.dart';

class Auth {
  static const _s = FlutterSecureStorage();
  static String _h(String v, String salt) => sha256.convert(utf8.encode('$salt:$v')).toString();
  static String _rnd(int n) {
    final r = Random.secure();
    return base64Url.encode(List.generate(n, (_) => r.nextInt(256)));
  }

  static Future<void> setPin(String pin) async {
    final salt = _rnd(16);
    await _s.write(key: 'salt', value: salt);
    await _s.write(key: 'pin', value: _h(pin, salt));
    await _s.write(key: 'fails', value: '0');
  }

  static Future<String> newRecovery() async {
    const a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    final r = Random.secure();
    final raw = List.generate(24, (_) => a[r.nextInt(a.length)]).join();
    final salt = _rnd(16);
    await _s.write(key: 'rsalt', value: salt);
    await _s.write(key: 'rec', value: _h(raw, salt));
    return [for (var i = 0; i < 24; i += 4) raw.substring(i, i + 4)].join('-');
  }

  static Future<bool> resetWithRecovery(String code, String newPin) async {
    final raw = code.replaceAll(RegExp(r'[\s-]'), '').toUpperCase();
    final salt = await _s.read(key: 'rsalt') ?? '';
    if (_h(raw, salt) != await _s.read(key: 'rec')) return false;
    await setPin(newPin);
    await _s.write(key: 'until', value: '0');
    return true;
  }

  static Future<int> lockedSecs() async {
    final u = int.tryParse(await _s.read(key: 'until') ?? '0') ?? 0;
    final d = u - DateTime.now().millisecondsSinceEpoch;
    return d > 0 ? (d / 1000).ceil() : 0;
  }

  static Future<bool> verify(String pin) async {
    final salt = await _s.read(key: 'salt') ?? '';
    if (_h(pin, salt) == await _s.read(key: 'pin')) {
      await _s.write(key: 'fails', value: '0');
      return true;
    }
    var f = (int.tryParse(await _s.read(key: 'fails') ?? '0') ?? 0) + 1;
    if (f >= 5) {
      f = 0;
      final t = DateTime.now().add(const Duration(minutes: 5)).millisecondsSinceEpoch;
      await _s.write(key: 'until', value: '$t');
    }
    await _s.write(key: 'fails', value: '$f');
    return false;
  }

  static Future<bool> bio() async {
    try {
      return await LocalAuthentication().authenticate(
          localizedReason: 'افتح سوقي بوكس',
          options: const AuthenticationOptions(biometricOnly: true));
    } catch (_) {
      return false;
    }
  }
}

class PinPad extends StatefulWidget {
  final String title;
  final Future<void> Function(String) onDone;
  const PinPad({super.key, required this.title, required this.onDone});
  @override
  State<PinPad> createState() => _PinPadState();
}

class _PinPadState extends State<PinPad> {
  String p = '';
  void _t(String d) {
    if (d == '<') {
      if (p.isNotEmpty) setState(() => p = p.substring(0, p.length - 1));
      return;
    }
    if (p.length >= 6) return;
    setState(() => p += d);
    if (p.length == 6) {
      final v = p;
      widget.onDone(v).whenComplete(() { if (mounted) setState(() => p = ''); });
    }
  }

  @override
  Widget build(BuildContext c) => Column(mainAxisSize: MainAxisSize.min, children: [
        Text(widget.title, style: Theme.of(c).textTheme.titleMedium),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (var i = 0; i < 6; i++)
            Container(margin: const EdgeInsets.all(6), width: 14, height: 14,
                decoration: BoxDecoration(shape: BoxShape.circle,
                    color: i < p.length ? AppState.I.seed : Colors.grey.shade400))
        ]),
        const SizedBox(height: 16),
        SizedBox(width: 260, child: Wrap(alignment: WrapAlignment.center, spacing: 12, runSpacing: 12, children: [
          for (final d in ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '<'])
            SizedBox(width: 76, height: 56, child: d.isEmpty ? null : FilledButton.tonal(
                onPressed: () => _t(d),
                child: d == '<' ? const Icon(Icons.backspace_outlined) : Text(d, style: const TextStyle(fontSize: 22))))
        ])),
      ]);
}

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});
  @override
  State<LockScreen> createState() => _LockState();
}

class _LockState extends State<LockScreen> {
  String shop = '';
  int wait = 0;
  bool bio = false;
  @override
  void initState() { super.initState(); _init(); }

  Future<void> _init() async {
    shop = await Db.get('shop') ?? '';
    bio = (await Db.get('bio')) == '1';
    wait = await Auth.lockedSecs();
    if (mounted) setState(() {});
    if (bio && wait == 0 && await Auth.bio()) _go();
  }

  void _go() { if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Home())); }

  Future<void> _check(String pin) async {
    if (await Auth.lockedSecs() == 0 && await Auth.verify(pin)) return _go();
    wait = await Auth.lockedSecs();
    if (!mounted) return;
    setState(() {});
    if (wait == 0) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(L.get('wrong_pin'))));
  }

  Future<void> _forgot() async {
    final code = TextEditingController(), pin = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (_) => AlertDialog(
          title: const Text('استرجاع الوصول'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: code, decoration: const InputDecoration(labelText: 'رمز الاسترجاع')),
            TextField(controller: pin, keyboardType: TextInputType.number, maxLength: 6, obscureText: true,
                decoration: const InputDecoration(labelText: 'رمز PIN جديد (6 أرقام)')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('تأكيد')),
          ]));
    if (ok != true || pin.text.length != 6) return;
    final done = await Auth.resetWithRecovery(code.text, pin.text);
    if (!mounted) return;
    setState(() => wait = 0);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(done ? 'تم تغيير الرمز' : 'رمز الاسترجاع غير صحيح')));
  }

  @override
  Widget build(BuildContext c) => Scaffold(
      body: SafeArea(child: Center(child: SingleChildScrollView(child: Column(children: [
        const Icon(Icons.lock_rounded, size: 48, color: AppState.I.seed),
        const SizedBox(height: 8),
        Text(shop, style: Theme.of(c).textTheme.headlineSmall),
        const SizedBox(height: 24),
        wait > 0 ? Text('مقفل مؤقتاً، حاول بعد $wait ثانية') : PinPad(title: L.get('enter_pin'), onDone: _check),
        if (bio) IconButton(iconSize: 40, icon: const Icon(Icons.fingerprint), onPressed: () async { if (await Auth.bio()) _go(); }),
        TextButton(onPressed: _forgot, child: Text(L.get('forgot_pin'))),
      ])))));
}

import 'package:flutter/material.dart';
import 'app_state.dart';
import 'backup.dart';
import 'business.dart';
import 'auth.dart';
import 'db.dart';
import 'l10n.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsState();
}

class _SettingsState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext c) {
    final s = AppState.I;
    return Scaffold(
      appBar: AppBar(title: Text(L.get('settings'))),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _section(L.get('language')),
          Card(
            child: Column(children: [
              RadioListTile<AppLang>(
                title: Text(L.get('arabic')),
                value: AppLang.ar,
                groupValue: L.lang,
                onChanged: (v) async {
                  if (v != null) {
                    await s.setLang(v);
                    setState(() {});
                  }
                },
              ),
              RadioListTile<AppLang>(
                title: Text(L.get('french')),
                value: AppLang.fr,
                groupValue: L.lang,
                onChanged: (v) async {
                  if (v != null) {
                    await s.setLang(v);
                    setState(() {});
                  }
                },
              ),
              RadioListTile<AppLang>(
                title: Text(L.get('english')),
                value: AppLang.en,
                groupValue: L.lang,
                onChanged: (v) async {
                  if (v != null) {
                    await s.setLang(v);
                    setState(() {});
                  }
                },
              ),
            ]),
          ),
          _section(L.lang == AppLang.fr ? 'Type de commerce' : L.lang == AppLang.en ? 'Business type' : 'نوع النشاط'),
          Card(
            child: Column(children: [
              for (final b in BizType.values)
                RadioListTile<BizType>(
                  secondary: Icon(b.icon, color: b.color),
                  title: Text(b.label),
                  value: b,
                  groupValue: s.biz,
                  onChanged: (v) async {
                    if (v != null) {
                      await s.setBiz(v);
                      setState(() {});
                    }
                  },
                ),
            ]),
          ),
          _section(L.get('theme')),
          Card(
            child: Column(children: [
              RadioListTile<ThemeMode>(
                title: Text(L.get('theme_light')),
                value: ThemeMode.light,
                groupValue: s.themeMode,
                onChanged: (v) async {
                  if (v != null) {
                    await s.setTheme(v);
                    setState(() {});
                  }
                },
              ),
              RadioListTile<ThemeMode>(
                title: Text(L.get('theme_dark')),
                value: ThemeMode.dark,
                groupValue: s.themeMode,
                onChanged: (v) async {
                  if (v != null) {
                    await s.setTheme(v);
                    setState(() {});
                  }
                },
              ),
              RadioListTile<ThemeMode>(
                title: Text(L.get('theme_system')),
                value: ThemeMode.system,
                groupValue: s.themeMode,
                onChanged: (v) async {
                  if (v != null) {
                    await s.setTheme(v);
                    setState(() {});
                  }
                },
              ),
            ]),
          ),
          _section(L.get('color')),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Wrap(
                spacing: 12,
                runSpacing: 12,
                children: [
                  for (final col in AppState.colors)
                    GestureDetector(
                      onTap: () async {
                        await s.setSeed(col);
                        setState(() {});
                      },
                      child: Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: col,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: s.seed.value == col.value
                                ? Theme.of(c).colorScheme.onSurface
                                : Colors.transparent,
                            width: 3,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: col.withValues(alpha: 0.4),
                              blurRadius: 8,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          _section(L.get('security')),
          Card(
            child: ListTile(
              leading: const Icon(Icons.lock_outline),
              title: Text(L.get('change_pin')),
              onTap: () => _changePin(c),
            ),
          ),
          _section(L.lang == AppLang.fr ? 'Sauvegarde' : L.lang == AppLang.en ? 'Backup' : 'نسخ احتياطي'),
          Card(
            child: Column(children: [
              ListTile(
                leading: const Icon(Icons.backup_rounded),
                title: Text(L.lang == AppLang.fr ? 'Exporter la sauvegarde' : L.lang == AppLang.en ? 'Export backup' : 'تصدير نسخة احتياطية'),
                subtitle: Text(L.lang == AppLang.fr ? 'Copier vers le presse-papiers' : L.lang == AppLang.en ? 'Copy to clipboard' : 'نسخ إلى الحافظة'),
                onTap: () => Backup.shareExport(context),
              ),
              ListTile(
                leading: const Icon(Icons.restore_rounded),
                title: Text(L.lang == AppLang.fr ? 'Restaurer' : L.lang == AppLang.en ? 'Restore' : 'استرجاع'),
                onTap: () => Backup.showImportDialog(context),
              ),
            ]),
          ),
          _section(L.get('about')),
          Card(
            child: ListTile(
              title: Text(L.get('app_name')),
              subtitle: Text('${L.get('tagline')}\n${L.get('signature')}'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 16, 4, 6),
        child: Text(t, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
      );

  Future<void> _changePin(BuildContext c) async {
    final old = TextEditingController(), n1 = TextEditingController(), n2 = TextEditingController();
    final ok = await showDialog<bool>(
      context: c,
      builder: (_) => AlertDialog(
        title: Text(L.get('change_pin')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: old, obscureText: true, keyboardType: TextInputType.number, maxLength: 6,
              decoration: InputDecoration(labelText: L.get('enter_pin'))),
          TextField(controller: n1, obscureText: true, keyboardType: TextInputType.number, maxLength: 6,
              decoration: InputDecoration(labelText: L.get('create_pin'))),
          TextField(controller: n2, obscureText: true, keyboardType: TextInputType.number, maxLength: 6,
              decoration: InputDecoration(labelText: L.get('confirm_pin'))),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(L.get('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(L.get('confirm'))),
        ],
      ),
    );
    if (ok != true) return;
    if (n1.text.length != 6 || n1.text != n2.text) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(L.get('pin_mismatch'))));
      }
      return;
    }
    if (!await Auth.verify(old.text)) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(L.get('wrong_pin'))));
      }
      return;
    }
    await Auth.setPin(n1.text);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(L.get('save'))));
    }
  }
}

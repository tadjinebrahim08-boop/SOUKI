import 'package:flutter/material.dart';
import 'app_state.dart';
import 'auth.dart';
import 'business.dart';
import 'db.dart';
import 'l10n.dart';
import 'main.dart';

class Onboarding extends StatefulWidget {
  const Onboarding({super.key});
  @override
  State<Onboarding> createState() => _OnState();
}

class _OnState extends State<Onboarding> {
  int step = 0;
  BizType biz = BizType.superMarket;
  final m = TextEditingController(), s = TextEditingController(), ph = TextEditingController(), w = TextEditingController();
  String? first, code, err;
  bool bio = true, saved = false;

  Widget _f(TextEditingController c, String l, [TextInputType? k]) => Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
          controller: c,
          keyboardType: k,
          decoration: InputDecoration(labelText: l, border: const OutlineInputBorder())));

  Future<void> _pin(String p) async {
    if (first == null) {
      setState(() {
        first = p;
        err = null;
      });
      return;
    }
    if (first != p) {
      setState(() {
        first = null;
        err = L.get('pin_mismatch');
      });
      return;
    }
    await Auth.setPin(p);
    code = await Auth.newRecovery();
    setState(() {
      step = 4;
      err = null;
    });
  }

  Future<void> _finish() async {
    await AppState.I.setBiz(biz);
    await Db.set('shop', s.text.trim());
    await Db.set('phone', ph.text.trim());
    await Db.set('wilaya', w.text.trim());
    await Db.set('bio', bio ? '1' : '0');
    await Db.set('merchant', m.text.trim());
    if (mounted) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const Home()));
    }
  }

  @override
  Widget build(BuildContext c) {
    final body = switch (step) {
      0 => [
          Icon(Icons.shopping_cart_rounded, size: 80, color: AppState.I.seed),
          Text(L.get('welcome'), style: Theme.of(c).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text(L.get('tagline'), textAlign: TextAlign.center),
          const SizedBox(height: 32),
          FilledButton(onPressed: () => setState(() => step = 1), child: Text(L.get('start'))),
        ],
      1 => [
          Text(L.lang == AppLang.fr ? 'Type de commerce' : L.lang == AppLang.en ? 'Business type' : 'نوع نشاطك',
              style: Theme.of(c).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text(L.lang == AppLang.fr
              ? 'Choisissez votre activité pour adapter le catalogue'
              : L.lang == AppLang.en
                  ? 'Choose your activity to adapt the catalog'
                  : 'اختر نشاطك باش يتكيّف الكتالوج معاك',
              textAlign: TextAlign.center,
              style: TextStyle(color: Theme.of(c).colorScheme.outline)),
          const SizedBox(height: 16),
          for (final b in BizType.values)
            Card(
              color: biz == b ? b.color.withValues(alpha: 0.12) : null,
              child: ListTile(
                leading: CircleAvatar(backgroundColor: b.color.withValues(alpha: 0.2), child: Icon(b.icon, color: b.color)),
                title: Text(b.label, style: const TextStyle(fontWeight: FontWeight.w600)),
                trailing: biz == b ? Icon(Icons.check_circle, color: b.color) : null,
                onTap: () => setState(() => biz = b),
              ),
            ),
          const SizedBox(height: 16),
          FilledButton(onPressed: () => setState(() => step = 2), child: Text(L.get('continue'))),
        ],
      2 => [
          Text(L.get('merchant_data'), style: Theme.of(c).textTheme.titleLarge),
          const SizedBox(height: 16),
          _f(m, L.get('merchant_name')),
          _f(s, L.get('shop_name')),
          _f(ph, L.get('phone'), TextInputType.phone),
          _f(w, L.get('wilaya')),
          FilledButton(
              onPressed: () {
                if (m.text.trim().isEmpty || s.text.trim().isEmpty) {
                  setState(() => err = L.get('required_fields'));
                } else {
                  setState(() {
                    step = 3;
                    err = null;
                  });
                }
              },
              child: Text(L.get('continue'))),
          if (err != null) Text(err!, style: const TextStyle(color: Colors.red)),
        ],
      3 => [
          PinPad(title: first == null ? L.get('create_pin') : L.get('confirm_pin'), onDone: _pin),
          if (err != null) Text(err!, style: const TextStyle(color: Colors.red)),
          SwitchListTile(title: Text(L.get('enable_bio')), value: bio, onChanged: (v) => setState(() => bio = v)),
        ],
      _ => [
          Icon(Icons.vpn_key_rounded, size: 56, color: AppState.I.seed),
          Text(L.get('recovery_code'), style: Theme.of(c).textTheme.titleLarge),
          const SizedBox(height: 12),
          SelectableText(code ?? '',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
          const SizedBox(height: 12),
          Text(L.get('recovery_hint'), textAlign: TextAlign.center),
          CheckboxListTile(value: saved, onChanged: (v) => setState(() => saved = v ?? false), title: Text(L.get('i_saved'))),
          FilledButton(onPressed: saved ? _finish : null, child: Text(L.get('enter'))),
        ],
    };
    return Scaffold(
        body: SafeArea(
            child: Center(
                child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24),
                    child: Column(mainAxisSize: MainAxisSize.min, children: body)))));
  }
}

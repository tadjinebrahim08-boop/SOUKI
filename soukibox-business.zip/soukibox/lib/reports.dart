import 'package:flutter/material.dart';
import 'db.dart';
import 'l10n.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});
  @override
  State<ReportsScreen> createState() => _ReportsState();
}

class _ReportsState extends State<ReportsScreen> {
  Map<String, double> stats = {};
  List<DbRow> low = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = await Db.todayStats();
    final all = await Db.products();
    final l = all.where((p) => (p['qty'] as num) <= (p['min_qty'] as num)).toList();
    if (mounted) setState(() { stats = s; low = l; });
  }

  Widget _statCard(IconData icon, Color color, String title, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: color.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: color, size: 28),
          ),
          const SizedBox(width: 16),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 13)),
            const SizedBox(height: 4),
            Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ])),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      appBar: AppBar(title: Text(L.get('reports'))),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            _statCard(Icons.shopping_bag_rounded, Colors.green, L.get('today_sales'), L.money(stats['sales'] ?? 0)),
            _statCard(Icons.trending_up_rounded, Colors.blue, L.get('today_profit'), L.money(stats['profit'] ?? 0)),
            _statCard(Icons.money_off_rounded, Colors.red, L.get('expenses_today'), L.money(stats['expenses'] ?? 0)),
            _statCard(Icons.warning_amber_rounded, Colors.orange, L.get('low_stock'), '${(stats['low'] ?? 0).toInt()}'),
            if (low.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(L.get('low_stock'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 8),
              for (final p in low)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.warning_amber_rounded, color: Colors.orange),
                    title: Text('${p['name']}'),
                    subtitle: Text('${L.get('stock_qty')}: ${p['qty']} / ${L.get('min_qty')}: ${p['min_qty']}'),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }
}

class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({super.key});
  @override
  State<ExpensesScreen> createState() => _ExpensesState();
}

class _ExpensesState extends State<ExpensesScreen> {
  List<DbRow> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await Db.expenses();
    if (mounted) setState(() => items = r);
  }

  Future<void> _add() async {
    final amount = TextEditingController();
    final note = TextEditingController();
    String cat = 'عام';
    final cats = ['عام', 'إيجار', 'كهرباء', 'نقل', 'أجور', 'أخرى'];
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: Text(L.get('add_expense')),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: amount,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: L.get('amount')),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              value: cat,
              items: cats.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: (v) => set(() => cat = v ?? cat),
              decoration: InputDecoration(labelText: L.get('category')),
            ),
            const SizedBox(height: 8),
            TextField(controller: note, decoration: InputDecoration(labelText: L.get('note'))),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(L.get('cancel'))),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(L.get('save'))),
          ],
        ),
      ),
    );
    final a = double.tryParse(amount.text);
    if (ok != true || a == null || a <= 0) return;
    await Db.addExpense(a, cat, note.text.trim());
    _load();
  }

  Future<void> _del(int id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(L.get('delete_confirm')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(L.get('no'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(L.get('yes'))),
        ],
      ),
    );
    if (ok == true) {
      await Db.deleteExpense(id);
      _load();
    }
  }

  @override
  Widget build(BuildContext c) {
    return Scaffold(
      appBar: AppBar(title: Text(L.get('expenses'))),
      floatingActionButton: FloatingActionButton(
        onPressed: _add,
        child: const Icon(Icons.add),
      ),
      body: items.isEmpty
          ? Center(child: Text(L.get('no_one')))
          : ListView.builder(
              itemCount: items.length,
              itemBuilder: (_, i) {
                final e = items[i];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.red.withValues(alpha: 0.15),
                      child: const Icon(Icons.money_off, color: Colors.red),
                    ),
                    title: Text(L.money(e['amount'] as num)),
                    subtitle: Text('${e['category']} • ${e['note'] ?? ''}\n${'${e['ts']}'.substring(0, 10)}'),
                    isThreeLine: true,
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.red),
                      onPressed: () => _del(e['id'] as int),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

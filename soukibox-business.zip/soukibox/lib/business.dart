import 'package:flutter/material.dart';
import 'l10n.dart';

enum BizType { superMarket, clothes, office, electronics, general }

extension BizTypeX on BizType {
  String get id => switch (this) {
        BizType.superMarket => 'super',
        BizType.clothes => 'clothes',
        BizType.office => 'office',
        BizType.electronics => 'electronics',
        BizType.general => 'general',
      };

  static BizType fromId(String? id) => switch (id) {
        'clothes' => BizType.clothes,
        'office' => BizType.office,
        'electronics' => BizType.electronics,
        'general' => BizType.general,
        _ => BizType.superMarket,
      };

  String get labelAr => switch (this) {
        BizType.superMarket => 'سوبرات / بقالة',
        BizType.clothes => 'ملابس وقش',
        BizType.office => 'أدوات مكتبية ومدرسية',
        BizType.electronics => 'هواتف وبيسيات',
        BizType.general => 'تجارة عامة',
      };

  String get labelFr => switch (this) {
        BizType.superMarket => 'Supérette / Épicerie',
        BizType.clothes => 'Prêt-à-porter',
        BizType.office => 'Papeterie',
        BizType.electronics => 'Téléphones & PC',
        BizType.general => 'Commerce général',
      };

  String get labelEn => switch (this) {
        BizType.superMarket => 'Grocery / Supermarket',
        BizType.clothes => 'Clothing',
        BizType.office => 'Stationery',
        BizType.electronics => 'Phones & PC',
        BizType.general => 'General trade',
      };

  String get label => switch (L.lang) {
        AppLang.fr => labelFr,
        AppLang.en => labelEn,
        _ => labelAr,
      };

  IconData get icon => switch (this) {
        BizType.superMarket => Icons.storefront_rounded,
        BizType.clothes => Icons.checkroom_rounded,
        BizType.office => Icons.menu_book_rounded,
        BizType.electronics => Icons.devices_rounded,
        BizType.general => Icons.store_rounded,
      };

  Color get color => switch (this) {
        BizType.superMarket => const Color(0xFF1B8A5A),
        BizType.clothes => const Color(0xFF7C3AED),
        BizType.office => const Color(0xFF2563EB),
        BizType.electronics => const Color(0xFF0891B2),
        BizType.general => const Color(0xFFEA580C),
      };
}

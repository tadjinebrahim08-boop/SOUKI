import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'db.dart';
import 'l10n.dart';

class Backup {
  static Future<String> exportJson() async {
    final products = await Db.products();
    final partiesC = await Db.parties('c');
    final partiesS = await Db.parties('s');
    final expenses = await Db.expenses();
    final shop = await Db.get('shop');
    final merchant = await Db.get('merchant');
    final biz = await Db.get('biz');
    final data = {
      'version': 1,
      'exported_at': DateTime.now().toIso8601String(),
      'shop': shop,
      'merchant': merchant,
      'biz': biz,
      'products': products,
      'customers': partiesC,
      'suppliers': partiesS,
      'expenses': expenses,
    };
    return const JsonEncoder.withIndent('  ').convert(data);
  }

  static Future<void> shareExport(BuildContext context) async {
    final json = await exportJson();
    await Clipboard.setData(ClipboardData(text: json));
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(L.lang == AppLang.fr
              ? 'Sauvegarde copiée. Collez-la dans un fichier texte et gardez-la.'
              : L.lang == AppLang.en
                  ? 'Backup copied. Paste into a text file and keep it safe.'
                  : 'تم نسخ النسخة الاحتياطية. الصقها في ملف نصي واحفظها.'),
          duration: const Duration(seconds: 4),
        ),
      );
    }
  }

  static Future<int> importJson(String raw) async {
    final data = jsonDecode(raw) as Map<String, dynamic>;
    var n = 0;
    final products = (data['products'] as List?) ?? [];
    for (final p in products) {
      final m = Map<String, Object?>.from(p as Map);
      m.remove('id');
      try {
        await Db.saveProduct(m);
        n++;
      } catch (_) {}
    }
    final customers = (data['customers'] as List?) ?? [];
    for (final p in customers) {
      final m = Map<String, Object?>.from(p as Map);
      try {
        await Db.addParty('c', '${m['name']}', '${m['phone'] ?? ''}');
        n++;
      } catch (_) {}
    }
    final suppliers = (data['suppliers'] as List?) ?? [];
    for (final p in suppliers) {
      final m = Map<String, Object?>.from(p as Map);
      try {
        await Db.addParty('s', '${m['name']}', '${m['phone'] ?? ''}');
        n++;
      } catch (_) {}
    }
    if (data['shop'] != null) await Db.set('shop', '${data['shop']}');
    if (data['merchant'] != null) await Db.set('merchant', '${data['merchant']}');
    if (data['biz'] != null) await Db.set('biz', '${data['biz']}');
    return n;
  }

  static Future<void> showImportDialog(BuildContext context) async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(L.lang == AppLang.fr
            ? 'Restaurer'
            : L.lang == AppLang.en
                ? 'Restore'
                : 'استرجاع نسخة'),
        content: SizedBox(
          width: double.maxFinite,
          child: TextField(
            controller: c,
            maxLines: 8,
            decoration: InputDecoration(
              hintText: L.lang == AppLang.fr
                  ? 'Collez le fichier JSON ici'
                  : L.lang == AppLang.en
                      ? 'Paste JSON backup here'
                      : 'الصق محتوى النسخة الاحتياطية هنا',
              border: const OutlineInputBorder(),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(L.get('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(L.get('confirm'))),
        ],
      ),
    );
    if (ok != true || c.text.trim().isEmpty) return;
    try {
      final n = await importJson(c.text.trim());
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${L.get('save')}: $n')));
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Error: $e')));
      }
    }
  }
}

import 'package:flutter/material.dart';
import 'app_state.dart';
import 'business.dart';
import 'auth.dart';
import 'db.dart';
import 'l10n.dart';
import 'onboarding.dart';
import 'parties.dart';
import 'pos.dart';
import 'settings.dart';
import 'stock.dart';
import 'reports.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Db.init();
  await AppState.I.load();
  runApp(const RootApp());
}

class RootApp extends StatefulWidget {
  const RootApp({super.key});
  @override
  State<RootApp> createState() => _RootAppState();
}

class _RootAppState extends State<RootApp> {
  @override
  void initState() {
    super.initState();
    AppState.I.addListener(_onChange);
  }

  @override
  void dispose() {
    AppState.I.removeListener(_onChange);
    super.dispose();
  }

  void _onChange() => setState(() {});

  @override
  Widget build(BuildContext context) {
    final s = AppState.I;
    return MaterialApp(
      title: L.get('app_name'),
      debugShowCheckedModeBanner: false,
      theme: s.theme(Brightness.light),
      darkTheme: s.theme(Brightness.dark),
      themeMode: s.themeMode,
      builder: (c, w) => Directionality(textDirection: L.dir, child: w!),
      home: const Splash(),
    );
  }
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  late final AnimationController _ac;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ac = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
    _scale = CurvedAnimation(parent: _ac, curve: Curves.easeOutBack);
    _ac.forward();
    Future.delayed(const Duration(milliseconds: 1800), () async {
      final done = await Db.get('merchant') != null;
      if (!mounted) return;
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => done ? const LockScreen() : const Onboarding()));
    });
  }

  @override
  void dispose() {
    _ac.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext c) {
    final color = AppState.I.seed;
    return Scaffold(
      backgroundColor: color,
      body: SafeArea(
        child: ScaleTransition(
          scale: _scale,
          child: Column(children: [
            const Spacer(flex: 3),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(28),
                boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 20, offset: Offset(0, 8))],
              ),
              child: const Icon(Icons.shopping_cart_rounded, size: 72, color: Colors.white),
            ),
            const SizedBox(height: 20),
            Text(L.get('app_name'),
                style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white)),
            const SizedBox(height: 8),
            Text(L.get('tagline'), style: const TextStyle(color: Colors.white70)),
            const Spacer(flex: 2),
            Text(L.get('signature'), style: const TextStyle(color: Colors.white60, fontSize: 12)),
            const SizedBox(height: 24),
          ]),
        ),
      ),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  int i = 0;
  DateTime? _bg;
  String shop = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    Db.get('shop').then((v) {
      if (mounted) setState(() => shop = v ?? '');
    });
    AppState.I.addListener(_refresh);
  }

  void _refresh() => setState(() {});

  @override
  void dispose() {
    AppState.I.removeListener(_refresh);
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.paused) _bg = DateTime.now();
    if (s == AppLifecycleState.resumed &&
        _bg != null &&
        DateTime.now().difference(_bg!).inSeconds > 30) {
      _bg = null;
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LockScreen()), (r) => false);
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(
          leading: Icon(AppState.I.biz.icon, color: AppState.I.biz.color),
          title: Text(shop.isEmpty ? L.get('app_name') : shop),
          actions: [
            IconButton(
              icon: const Icon(Icons.settings_outlined),
              onPressed: () =>
                  Navigator.push(c, MaterialPageRoute(builder: (_) => const SettingsScreen())),
            ),
          ],
        ),
        body: [const PosScreen(), const StockScreen(), const MoreScreen()][i],
        bottomNavigationBar: NavigationBar(
          selectedIndex: i,
          onDestinationSelected: (v) => setState(() => i = v),
          destinations: [
            NavigationDestination(icon: const Icon(Icons.point_of_sale_rounded), label: L.get('sell')),
            NavigationDestination(icon: const Icon(Icons.inventory_2_rounded), label: L.get('stock')),
            NavigationDestination(icon: const Icon(Icons.grid_view_rounded), label: L.get('more')),
          ],
        ),
      );
}

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  Widget _card(BuildContext c, IconData icon, Color color, String title, String sub, Widget page) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.15),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 28),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => page)),
      ),
    );
  }

  @override
  Widget build(BuildContext c) {
    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 8),
      children: [
        _card(c, Icons.people_alt_rounded, Colors.blue, L.get('customers'), L.get('customers'),
            const PartiesScreen('c')),
        _card(c, Icons.local_shipping_rounded, Colors.orange, L.get('suppliers'), L.get('suppliers'),
            const PartiesScreen('s')),
        _card(c, Icons.receipt_long_rounded, Colors.teal, L.get('expenses'), L.get('expenses'),
            const ExpensesScreen()),
        _card(c, Icons.bar_chart_rounded, Colors.purple, L.get('reports'), L.get('reports'),
            const ReportsScreen()),
        _card(c, Icons.settings_rounded, Colors.grey, L.get('settings'), L.get('settings'),
            const SettingsScreen()),
        const SizedBox(height: 16),
        Center(
          child: Text('${L.get('app_name')}\n${L.get('tagline')}\n${L.get('signature')}',
              textAlign: TextAlign.center,
              style: TextStyle(color: Theme.of(c).colorScheme.outline, fontSize: 12)),
        ),
        const SizedBox(height: 24),
      ],
    );
  }
}
